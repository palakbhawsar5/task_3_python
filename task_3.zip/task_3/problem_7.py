for i in range(1,int(input())):
    print(i*((10**i-1)//9))