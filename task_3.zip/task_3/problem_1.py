import cmath
n = input()
s = complex(n)
print(abs(s))
print(cmath.phase(s))